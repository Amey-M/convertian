package codes;

public class Power {
	static Double toW(Double v, String key) // toWatts
	{
		if (key == "mw") {
			return v * 1000000.0;
		}
		if (key == "gw") {
			return v * 1000000000.0;
		}
		if (key == "tw") {
			return v * 1000000000000.0;
		}
		if (key == "hp") {
			return v * 745.7;
		}

		return v;

	}

	static Double toMw(Double v, String key) // toMegaWatts
	{
		if (key == "w") {
			return v / 1000000.0;
		}
		if (key == "gw") {
			return v * 1000.0;
		}
		if (key == "tw") {
			return v * 1000000.0;
		}
		if (key == "hp") {
			return v * 0.0007457;
		}

		return v;

	}

	static Double toGw(Double v, String key) // toGigaWatts
	{
		if (key == "w") {
			return v / 1000000000.0;
		}
		if (key == "mw") {
			return v / 1000.0;
		}
		if (key == "tw") {
			return v * 1000.0;
		}
		if (key == "hp") {
			return v / 1341000;
		}

		return v;
	}

	static Double toTw(Double v, String key) // toTeraWatts
	{
		if (key == "w") {
			return v / 1000000000000.0;
		}
		if (key == "gw") {
			return v / 1000.0;
		}
		if (key == "mw") {
			return v / 1000000.0;
		}
		if (key == "hp") {
			return v / 1341000000;
		}

		return v;
	}

	static Double toHp(Double v, String key) // toHorsePower
	{
		if (key == "W") {
			return v * 0.00134102;
		}
		if (key == "gw") {
			return v * 1341000;
		}
		if (key == "mw") {
			return v * 1341.02;
		}
		if (key == "tw") {
			return v / 1341000000;
		}
		return v;
	}

}