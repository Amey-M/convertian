package codes;

public class Length {

	public Double toMm(Double v, String key) {
		if (key == "cm") {
			return v * 10;
		} else if (key == "m") {
			return v * 1000;
		} else if (key == "km") {
			return v * 1000000;
		} else if (key == "mile") {
			return v * 1609340;
		} else if (key == "yd") {
			return v * 914.4;
		} else if (key == "ft") {
			return v * 304.8;
		} else if (key == "inch") {
			return v * 25.4;
		} else if (key == "lightyear") {
			return v * 9461000000000000000.0;
		}
		return v;
	}

	public Double toCm(Double v, String key) {
		if (key == "mm") {
			return v * 0.1;
		} else if (key == "m") {
			return v * 100;
		} else if (key == "km") {
			return v * 100000;
		} else if (key == "mile") {
			return v * 160934;
		} else if (key == "yd") {
			return v * 91.44;
		} else if (key == "ft") {
			return v * 30.48;
		} else if (key == "inch") {
			return v * 2.54;
		} else if (key == "lightyear") {
			return v * 946100000000000000.0;
		}
		return v;
	}

	public Double toM(Double v, String key) {
		if (key == "mm") {
			return v * 0.001;
		} else if (key == "cm") {
			return v * 0.01;
		} else if (key == "km") {
			return v * 1000;
		} else if (key == "mile") {
			return v * 1609.34;
		} else if (key == "yd") {
			return v * 0.9144;
		} else if (key == "ft") {
			return v * 0.3048;
		} else if (key == "inch") {
			return v * 0.0254;
		} else if (key == "lightyear") {
			return v * 9461000000000000.0;
		}
		return v;
	}

	public Double toKm(Double v, String key) {
		if (key == "mm") {
			return v * 0.000001;
		} else if (key == "cm") {
			return v * 0.00001;
		} else if (key == "m") {
			return v * 0.001;
		} else if (key == "mile") {
			return v * 1.60934;
		} else if (key == "yd") {
			return v * 0.0009144;
		} else if (key == "ft") {
			return v * 0.0003048;
		} else if (key == "inch") {
			return v * 0.0000254;
		} else if (key == "lightyear") {
			return v * 946100000000000.0;
		}
		return v;
	}

	public Double toMile(Double v, String key) {
		if (key == "mm") {
			return v * 0.00000062317;
		} else if (key == "cm") {
			return v * 0.0000062317;
		} else if (key == "m") {
			return v * 0.000621371;
		} else if (key == "km") {
			return v * 0.62137100;
		} else if (key == "yd") {
			return v * 0.000568182;
		} else if (key == "ft") {
			return v * 0.000189394;
		} else if (key == "inch") {
			return v * 0.000015783;
		} else if (key == "lightyear") {
			return v * 5879000000000.0;
		}
		return v;
	}

	public Double toYd(Double v, String key) {
		if (key == "mm") {
			return v * 0.00109361;
		} else if (key == "cm") {
			return v * 0.0109361;
		} else if (key == "m") {
			return v * 1.09361;
		} else if (key == "km") {
			return v * 1093.61;
		} else if (key == "mile") {
			return v * 1760;
		} else if (key == "ft") {
			return v * 0.333333;
		} else if (key == "inch") {
			return v * 0.0277778;
		} else if (key == "lightyear") {
			return v * 10346388930000000.0;
		}
		return v;
	}

	public Double toFt(Double v, String key) {
		if (key == "mm") {
			return v * 0.00328084251969;
		} else if (key == "cm") {
			return v * 0.032808425196899998477;
		} else if (key == "m") {
			return v * 3.28084;
		} else if (key == "km") {
			return v * 3280.84;
		} else if (key == "mile") {
			return v * 5280;
		} else if (key == "yd") {
			return v * 3;
		} else if (key == "inch") {
			return v * 0.0833333;
		} else if (key == "lightyear") {
			return v * 310400000000000000.0;
		}
		return v;
	}

	public Double toInch(Double v, String key) {
		if (key == "mm") {
			return v * 0.0393701;
		} else if (key == "cm") {
			return v * 0.393701;
		} else if (key == "m") {
			return v * 39.3701;
		} else if (key == "km") {
			return v * 39370.1;
		} else if (key == "mile") {
			return v * 63360;
		} else if (key == "yd") {
			return v * 36;
		} else if (key == "ft") {
			return v * 12;
		} else if (key == "lightyear") {
			return v * 372500000000000000.0;
		}
		return v;
	}

	public Double toLightyear(Double v, String key) {
		if (key == "mm") {
			return v * 0.00000000000000000001057;
		} else if (key == "cm") {
			return v * 0.0000000000000000001057;
		} else if (key == "m") {
			return v * 0.0000000000000001057;
		} else if (key == "km") {
			return v * 0.0000000000001057;
		} else if (key == "mile") {
			return v * 0.00000000000017011;
		} else if (key == "yd") {
			return v * 0.000000000000000096652;
		} else if (key == "ft") {
			return v * 0.000000000000000032217;
		} else if (key == "inch") {
			return v * 0.0000000000000000026848;
		}
		return v;
	}
}
