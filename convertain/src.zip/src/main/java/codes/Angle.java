package codes;

public class Angle {
	public Double toDegree(Double v, String key) {
		if (key == "rad") {
			return v * 57.29;
		}
		if (key == "rev") {
			return v * 360.0;
		}
		return v;

	}

	public Double toRadian(Double v, String key) {
		if (key == "deg") {
			return v * 0.0174533;
		}
		if (key == "rev") {
			return v * 6.28319;
		}
		return v;
	}

	public Double toRev(Double v, String key) {
		if (key == "deg") {
			return v * 0.00277778;
		}
		if (key == "rad") {
			return v * 0.159155;
		}
		return v;
	}

}