import codes.*;
public class Main {
	public static void main(String args[])
	{
		Area n=new Area();
	  System.out.println(n.toCm2(100,"mm"));
	}


}
