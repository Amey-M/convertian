package com.ctrl;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import codes.Weight;

@Controller
@RequestMapping("/Weight")
public class WeightCtrl 
{
	Weight weight;
	@RequestMapping("/toMg")
	public String toMg(double value,String key)
	{
		double answers=weight.toMg(value,key);
		
		return "weight?value="+answers;
	}	
	
	@RequestMapping("/toG")
	public String toG(double value,String key)
	{
		double answers =weight.toG(value,key);
		
		return "weight?value="+answers;
	}	
	
	@RequestMapping("/toKg")
	public String toKg(double value,String key)
	{
		double answers =weight.toKg(value,key);
		
		return "weight?value="+answers;
	}	
	
	@RequestMapping("/toTon")
	public String toTon(double value,String key)
	{
		double answers =weight.toTon(value,key);
		
		return "weight?value="+answers;
	}	
	
	@RequestMapping("/toPd")
	public String toPd(double value,String key)
	{
		double answers =weight.toPd(value,key);
		
		return "weight?value="+answers;
	}	
	
	
	@RequestMapping("/toQuint")
	public String toQuint(double value,String key)
	{
		double answers =weight.toQunit(value,key);
		
		return "weight?value="+answers;
	}	
	
}