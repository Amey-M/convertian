package com.ctrl;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import codes.Temperature;

@Controller
@RequestMapping("/Temperature")
public class TemperatureCtrl {
	Temperature temperature;
	@RequestMapping("/toC")
	public String toC(double value,String str)
	{
		double answers=temperature.toC(value,str);
		
		return "currency?value="+answers;
	}
	
	@RequestMapping("/toK")
	public String toK(double value,String str)
	{
		double answers=temperature.toK(value,str);
		
		return "currency?value="+answers;
	}
	
	@RequestMapping("/toF")
	public String toF(double value,String str)
	{
		double answers =temperature.toF(value,str);
		
		return "currency?value="+answers;
	}
}