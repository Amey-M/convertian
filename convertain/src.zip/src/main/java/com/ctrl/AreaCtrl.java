package com.ctrl;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import codes.Area;
@Controller
@RequestMapping("/Area")
public class AreaCtrl {
	Area area;
	@RequestMapping("/toMm2")
	public String toMm(double value,String str)
	{
		double answers =area.toMm2(value,str);
		
		return "area?value="+answers;
	}
	@RequestMapping("/toCm2")
	public String toCm(double value,String str)
	{
		double answers =area.toCm2(value,str);
		
		return "area?value="+answers;
	}
	@RequestMapping("/toKm2")
	public String toKm(double value,String str)
	{
		double answers =area.toKm2(value,str);
		
		return "area?value="+answers;
	}
	@RequestMapping("/toAcre")
	public String toAcre(double value,String str)
	{
		double answers =area.toAcre(value,str);
		
		return "area?value="+answers;
	}
	@RequestMapping("/toHect")
	public String toHect(double value,String str)
	{
		double answers =area.toHect(value,str);
		
		return "area?value="+answers;
	}





}
