package com.ctrl;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import codes.Angle;

@Controller
@RequestMapping("/Angle")
public class AngleCtrl {
	Angle angle;

	@RequestMapping("/toDegree")
	public String toDegree(double value, String str) {
		double answers = angle.toDegree(value, str);

		return "angle?value=" + answers;
	}

	@RequestMapping("/toRadian")
	public String toRadian(double value, String str) {
		double answers = angle.toRadian(value, str);

		return "angle?value=" + answers;
	}

	@RequestMapping("/toRev")
	public String toRev(double value, String str) {
		double answers = angle.toRev(value, str);

		return "angle?value=" + answers;
	}

}