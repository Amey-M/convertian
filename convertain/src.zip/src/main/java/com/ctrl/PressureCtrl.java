package com.ctrl;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import codes.Pressure;
@Controller
public class PressureCtrl {
	@RequestMapping(path="pressureprocess",method=RequestMethod.POST)
	public String toInr(@RequestParam("from") double uservalue,@RequestParam("currency") int fromval,@RequestParam("currencyto") int fromval2, Model model) {
		
		System.out.println("user has entered this value "+ uservalue+"option"+fromval+"option2"+fromval2);

		/*if(fromval==1)
		{
			double result=toInr(uservalue,);
		}*/
		
		
	
		return "pressureSuc";
	}
}	