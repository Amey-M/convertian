package com.ctrl;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import codes.Number_System;

@Controller
@RequestMapping("/numbersystem")
public class Number_SystemCtrl {
	Number_System number_system;
	@RequestMapping("/toBinary")
	public String toBinary(String value,String str)
	{
		String answers =number_system.toBinary(value,str);
		
		return "number_system?value="+answers;
	}

	@RequestMapping("/toDecimal")
	public String toDecimal(String value,String str)
	{
		double answers =number_system.toDecimal(value,str);
		
		return "number_system?value="+answers;
	}

	@RequestMapping("/toOctal")
	public String toOctal(String value,String str)
	{
		String answers =number_system.toOctal(value,str);
		
		return "number_system?value="+answers;
	}
	
	@RequestMapping("/toHexa")
	public String toHexa(String value,String str)
	{
		String answers =number_system.toHexa(value,str);
		
		return "number_system?value="+answers;
	}

	
}