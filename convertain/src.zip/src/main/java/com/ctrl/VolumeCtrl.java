package com.ctrl;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import codes.Volume;

@Controller
@RequestMapping("/Volume")
public class VolumeCtrl {
	Volume volume;

	@RequestMapping("/toMl")
	public String toInr(double value, String str) {
		double answers = volume.toMl(value, str);

		return "currency?value=" + answers;
	}

	@RequestMapping("/toL")
	public String toUsd(double value, String str) {
		double answers = volume.toL(value, str);

		return "currency?value=" + answers;
	}

	@RequestMapping("/toKl")
	public String toKl(double value, String str) {
		double answers = volume.toKl(value, str);

		return "currency?value=" + answers;
	}

	@RequestMapping("/toGal")
	public String toGal(double value, String str) {
		double answers = volume.toGal(value, str);

		return "currency?value=" + answers;
	}

	@RequestMapping("/toCc")
	public String toCc(double value, String str) {
		double answers = volume.toCc(value, str);

		return "currency?value=" + answers;
	}

	@RequestMapping("/toM3")
	public String toM3(double value, String str) {
		double answers = volume.toM3(value, str);

		return "currency?value=" + answers;
	}

}