package com.ctrl;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import codes.Currency;
@Controller
public class CurrencyCtrl {
	@RequestMapping(path="currencyprocess",method=RequestMethod.POST)
	public String toInr(@RequestParam("from") double uservalue,@RequestParam("currency") int fromval,@RequestParam("currencyto") int fromval2, Model model) {
		
		System.out.println("user has entered this value "+ uservalue+"option"+fromval+"option2"+fromval2);

		/*if(fromval==1)
		{
			double result=toInr(uservalue,);
		}*/
		model.addAttribute("from",uservalue);
		model.addAttribute("currency",fromval);
		model.addAttribute("currencyto",fromval2);
		
	
		return "currencySuc";
	}
}	